document.addEventListener("DOMContentLoaded", function() {
    let clicks = 0;
    let earnings = 0;

    document.getElementById("getAdBtn").addEventListener("click", function() {
        clicks++;
        earnings += 0.10; // Each ad click earns $0.10
        document.getElementById("clicks").innerText = clicks;
        document.getElementById("earned").innerText = earnings.toFixed(2);
        document.getElementById("current-balance").innerText = `$${earnings.toFixed(2)}`;
    });

    document.getElementById("confirmWithdraw").addEventListener("click", function() {
        let withdrawAmount = parseFloat(document.getElementById("withdrawAmount").value);
        if (withdrawAmount > 0 && withdrawAmount <= earnings) {
            alert(`Withdrawal of $${withdrawAmount.toFixed(2)} confirmed.`);
            earnings -= withdrawAmount;
            document.getElementById("earned").innerText = earnings.toFixed(2);
            document.getElementById("current-balance").innerText = `$${earnings.toFixed(2)}`;
            document.getElementById("withdrawAmount").value = '';
        } else {
            alert("Invalid withdrawal amount.");
        }
    });

    document.getElementById("cancelWithdraw").addEventListener("click", function() {
        document.getElementById("withdrawAmount").value = '';
    });
});
